﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form 
    {
        class employee

        {
         
          protected string fname;
          protected string lname;

          public employee (string fn, string ln)
          {
                if (fn.Length == 0)
                {
                    MessageBox.Show("invalid name - setting to jabarjung singh");
                    this.fname = "jabarjung";
                    this.lname = "singh";

                }
                else
                {
                    this.fname = fn;
                    this.lname = ln;
                    MessageBox.Show("inside employee constructor");
                }


                }
            public string Fname
            { 
                get { return fname; } 
                set { fname = value; }
            
            }
            public void display() 
            {
                MessageBox.Show("inside employee display" + fname + " " + lname);


            }

        }
        class FT :employee
        {
            private double salary;
            public FT(string fn, string ln, double sal) :base(fn,ln)
            {
                if (sal <= 10000.00)
                {
                    MessageBox.Show("10k is too low - upping to 50k ");
                    salary = 50000.00;

                }
                else 
                {
                    salary = sal;
                  
                
                }

            }
            public void display() 
            {
             base.display();
             MessageBox.Show("in FT display" + salary.ToString());
                

            
            }

            

       

        }


        public Form1()
        {
            InitializeComponent();
        }

        private void addEmpBTN_Click(object sender, EventArgs e)
        {
            employee e1 = new employee(textBox1.Text, textBox2.Text);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            FT f1 = new FT(textBox1.Text, textBox2.Text, double.Parse(textBox3.Text));// needs error checking!
            f1.display();


        }
        class PT : employee
        {
            private double payrate;

            public PT(string fn, string ln, double pr) : base(fn, ln) 
            {

                if (pr <= 15.00) 
                {
                    MessageBox.Show(" too low - set to 17");
                    payrate = 17.00;

                }
                else 
                {
                  payrate = pr; 
                }





            }
                public void dsiplay() 
                {
                base.display();
                MessageBox.Show("in PART time dosplay " + payrate.ToString());
                
                }
           
        
            
            
            

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void addPTBTN_Click(object sender, EventArgs e)
        {
      
            PT p1 = new PT(textBox1.Text, textBox2.Text, double.Parse(textBox4.Text));// needs error checking!
            p1.display();
        }
    }
}
